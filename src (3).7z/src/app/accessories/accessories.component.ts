import { Component, OnInit } from '@angular/core';
import {IAccessories} from './accessories';
import {ProductService} from '../product.service'

@Component({
  selector: 'app-accessories',
  templateUrl: './accessories.component.html',
  styleUrls: ['./accessories.component.css']
})
export class AccessoriesComponent implements OnInit {
  pageTitle="Accessories List";
  Accessory:IAccessories[];
  imageWidth:number=200;
  imageHeight:number=200;
  constructor(private productService:ProductService) { }
  getAccessories():void{
    this.Accessory=this.productService.getAccessories();
  }
  ngOnInit() {
    this.getAccessories();
  }

}
