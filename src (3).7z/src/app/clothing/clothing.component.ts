import { Component, OnInit } from '@angular/core';
import {IClothing} from './cloth';

import {ProductService} from '../product.service'
@Component({
  selector: 'app-clothing',
  templateUrl: './clothing.component.html',
  styleUrls: ['./clothing.component.css']
})
export class ClothingComponent implements OnInit {
pageTitle="Clothing List";
 Cloth:IClothing[];
  imageWidth:number=200;
  imageHeight:number=200;
  constructor(private productService:ProductService) { }

  getClothing():void
  {
    this.Cloth=this.productService.getClothing();
  }
  ngOnInit() {
    this.getClothing();

  }

}
