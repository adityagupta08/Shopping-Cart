import { Injectable } from '@angular/core';

import {Grocery} from '../app/grocery/grocery';
import {GROCERIES} from '../app/grocery/mock-groceries';

import {IElectronic} from '../app/electronics/electronics'
import {ELECTRONICS} from '../app/electronics/mock-electronics'

import {IAccessories} from '../app/accessories/accessories'
import {ACCESSORIES} from '../app/accessories/mock-accessories'

import {Stationary} from '../app/stationary/stationary'
import {STATIONARIES} from '../app/stationary/mock-stationaries'

import {IClothing} from '../app/clothing/cloth';
import {CLOTHING} from '../app/clothing/mock-clothes';



@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor() { }
  getGroceries():Grocery[]{
    return GROCERIES;
  }

  getElectronics():IElectronic[]{
    return ELECTRONICS;
  }

  getAccessories():IAccessories[]{
    return ACCESSORIES;
  }

  getStationaries():Stationary[]{
    return STATIONARIES;
  }

  getClothing(): IClothing[]
  {
    return CLOTHING;
  } 
}
