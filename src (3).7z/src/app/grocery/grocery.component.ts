import { Component, OnInit } from '@angular/core';
import {Grocery} from './grocery';
import {ProductService} from '../product.service'


@Component({
  selector: 'app-grocery',
  templateUrl: './grocery.component.html',
  styleUrls: ['./grocery.component.css']
})
export class GroceryComponent implements OnInit {

 groceries:Grocery[];
  constructor(private productService:ProductService) { }
 getGroceries():void{
   this.groceries=this.productService.getGroceries();
 }
  ngOnInit() {
   this.getGroceries();
  }
 
}
