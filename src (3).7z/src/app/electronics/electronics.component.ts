import { Component, OnInit } from '@angular/core';
import {IElectronic} from './electronics';
import {ProductService} from '../product.service'

@Component({
  selector: 'app-electronics',
  templateUrl: './electronics.component.html',
  styleUrls: ['./electronics.component.css']
})
export class ElectronicsComponent implements OnInit {
pageTitle="Electronics List";
Electronics:IElectronic[];
imageWidth:number=150;
         imageMargin:number=20;
constructor(private productService:ProductService) { }
getElectronics():void{
  this.Electronics=this.productService.getElectronics();
}
  ngOnInit() {
    this.getElectronics();
  }

}
